import random
from logging import exception

import pandas as pd
from tabulate import tabulate
from abc import ABC, abstractmethod


class Game(ABC):
    def __init__(self, player_list):
        self.player_list = player_list

    @abstractmethod
    def start_game(self):
        pass

    def print_dice(self, no):
        if no == 1:
            print("[-----]")
            print("[     ]")
            print("[  0  ]")
            print("[     ]")
            print("[-----]")
        if no == 2:
            print("[-----]")
            print("[ 0   ]")
            print("[     ]")
            print("[   0 ]")
            print("[-----]")
        if no == 3:
            print("[-----]")
            print("[     ]")
            print("[0 0 0]")
            print("[     ]")
            print("[-----]")
        if no == 4:
            print("[-----]")
            print("[0   0]")
            print("[     ]")
            print("[0   0]")
            print("[-----]")
        if no == 5:
            print("[-----]")
            print("[0   0]")
            print("[  0  ]")
            print("[0   0]")
            print("[-----]")
        if no == 6:
            print("[-----]")
            print("[0 0 0]")
            print("[     ]")
            print("[0 0 0]")
            print("[-----]")


class Odd_Even(Game):
    def __init__(self, player_list):
        self.player_list = player_list

    def start_game(self):
        flag = -1
        if len(self.player_list) > 0:
            print('Hey ' + self.player_list[0] + ', Odd (o) oe Even (e)?')
            while True:
                try:
                    choice = input()
                    if choice != 'o' and choice != 'e':
                        print('Invalid choice')
                        print('Odd (o) oe Even (e)?')
                    else:
                        while True:
                            print('How strong will you throw (0-5)?')
                            try:
                                strong = int(input())
                                if strong > 0 and strong < 6:
                                    a = random.randint(1, 6)
                                    self.print_dice(a)
                                    if a % 2 == 0 and choice == 'e':
                                        print('Congratulations, ' + self.player_list[0] + "! You win!")
                                        flag = 1
                                        break
                                    elif a % 2 == 1 and choice == 'o':
                                        print('Congratulations, ' + self.player_list[0] + "! You win!")
                                        flag = 1
                                        break
                                    else:
                                        print('Sorry, ' + self.player_list[0] + "! You lose!")
                                        flag = 0
                                        break
                                else:
                                    print('Invalid choice.')
                            except ValueError:
                                print('Enter correct input')
                                pass
                        if flag >= 0:
                            break
                except exception as e:
                    pass

        else:
            print('No player found')


class Maxi(Game):
    def __init__(self, player_list, score):
        self.player_left = player_list.copy()
        self.score = score

    def start_game(self):
        if len(self.player_left)<3:
            print('Not enough players to play Maxi')
            return

        print('Let the game begin !')

        while True:
            player_score = []
            for player in self.player_left:
                print('Let\'s ' + player + '\'s turn.')
                print('How strong will you throw (0-5)?')
                try:
                    strong = int(input())
                    a = random.randint(1, 6)
                    b = random.randint(1, 6)
                    sum = a+b
                    self.print_dice(a)
                    self.print_dice(b)
                    player_score.append(sum)
                except ValueError:
                    print('Enter correct input')
                    pass
            minval=min(player_score)
            minpos = player_score.index(minval)
            player_score.pop(minpos)

            self.player_left.pop(minpos)
            if len(player_score) < 2:
                print('Congratulations, ' + self.player_left[-1] + '! you win!')
                break
            else:
                print('Players remaining: ')
                for item in self.player_left:
                    print(item + ', ', end='')

class Leaderboard:
    def __init(self, player_list, score):
        self.player_list = player_list
        self.bunco_player = []
        self.chips = []
        self.score = score


class Bunco(Game):
    def __init__(self, player_list, score):
        self.player_list = player_list
        self.bunco_player = []
        self.chips = []
        self.score = score

    def bid_chips(self, player_name):
        while True:
            try:
                print('How many chips would you bid ' + player_name + '(1-70)')
                chips = int(input())
                if chips < 1 or chips > 70:
                    print('Invalid number of chips.')
                else:
                    return chips
            except ValueError:
                print('Enter correct input')
                pass

    def play_game(self):
        if len(self.player_list)<2:
            print('Not enough players to play bunco')
            return
        
        round_score = []
        bunco_record = []
        for i in range(1, 7):
            print('<Round ' + str(i) + '>')
            j = 0
            player_score = []
            for player in self.bunco_player:
                print("It's " + player + "'s turn")
                award = 0
                bunco = 0
                while True:
                    try:
                        award_lcl = 0
                        print('How strong will you throw (0-5)?')
                        thr = input()
                        a = random.randint(1, 6)
                        b = random.randint(1, 6)
                        c = random.randint(1, 6)
                        self.print_dice(a)
                        self.print_dice(b)
                        self.print_dice(c)
                        if a == i:
                            award = award + 1
                            award_lcl = 1
                        if b == i:
                            award = award + 1
                            award_lcl = 1
                        if c == i:
                            award = award + 1
                            award_lcl = 1
                        if a == i and b == i and c == i:
                            award_lcl = 21
                            bunco = bunco + 1
                            print('Bunco!')
                            print('You earned 21 points, ' + str(award) + ' point in total')
                            print(player + ' is the winner in round ' + str(i) + '!')
                            award = award + 21
                        if a == b and b == c and c != i:
                            award = award + 5
                            award_lcl = 5
                        print('You earned ' + str(award_lcl) + ' points ' + str(award) + ' points in total.')
                        if award_lcl == 0:
                            break
                    except ValueError:
                        print('Enter correct input')
                        pass
                j = j + 1
                bunco_record.append(({player: [bunco]}))
                player_score.append({player: award})
            round_score.append(player_score)

        round = [1, 2, 3, 4, 5, 6]
        list_player = []
        for player in self.bunco_player:
            player_item_list = []
            for item in round_score:
                for x in range(0, len(self.bunco_player)):
                    if item[x].get(player) != None:
                        player_item_list.append(item[x].get(player))
            list_player.append({player: player_item_list})

        dict_1 = {'Round': round}
        for item in list_player:
            dict_1.update(item)

        df = pd.DataFrame(dict_1)
        print(tabulate(df, headers='keys', tablefmt='psql', showindex=False))
        df_01 = df.sum(axis='index')
        print(df_01)

        dict_1 = {'Bunco': ['Bunco']}
        for item in bunco_record:
            dict_1.update(item)

        df_1 = pd.DataFrame(dict_1)
        print(tabulate(df_1, headers='None', tablefmt='psql', showindex=False))

    def start_game(self):
        print("Let's play the game of Bunco!")
        print('How many player (2-4)?')
        nos_player = input()
        i = 1
        while True:
            try:
                print("What is the name of player #" + str(i))
                player_name = input()
                if player_name in self.player_list:
                    if player_name not in self.bunco_player:
                        self.bunco_player.append(player_name)
                        chips = self.bid_chips(player_name)
                        self.score.append(0)
                        self.chips.append(chips)
                        i = i + 1
                    else:
                        print(player_name + ' already in the game')
                else:
                    print('There is no player named ' + player_name)

                if i > int(nos_player):
                    break
            except ValueError:
                print('Enter correct input')
                pass
        self.play_game()


class Player:
    def __init__(self, player_list):
        self.player_name = player_list
        self.name = ""

    def register(self):
        try:
            print("What is the name of new player")
            self.name = input()
            if self.name in self.player_name:
                print("Sorry, the name is already taken")
                return
            print("Welcome, " + self.name)
            return self.name
        except ValueError:
            print('Enter correct input')
            pass


class AllThatDice():
    def __init__(self):
        self.player_list = []
        self.score = []

    def run(self):
        self.menu()

    def menu(self):
        while True:
            try:

                print("\nWhat would you like to do?")
                print("(r) register a new player")
                print("(s) show the leader board")
                print("(p) play a game")
                print("(q) quit")
                choice = input()
                if choice == "r":
                    p = Player(self.player_list)
                    new_name = p.register()
                    if new_name is not None:
                        self.player_list.append(new_name)
                elif choice == 'p':
                    print("Which game would you like to play?")
                    print("(o) Odd-or-Even")
                    print("(m) Maxi")
                    print("(b) Bunco")
                    game_choice = input()
                    if game_choice == 'o':
                        odd_even = Odd_Even(self.player_list)
                        odd_even.start_game()
                    elif game_choice == 'b':
                        bunco = Bunco(self.player_list, self.score)
                        bunco.start_game()
                    elif game_choice == 'm':
                        bunco = Maxi(self.player_list, self.score)
                        bunco.start_game()
                if choice == "q":
                    exit(1)
            except ValueError:
                print('Enter correct input')
                pass


atd = AllThatDice()
atd.run()
